# Example configuration file for compiling for an Atmel SAM D20 Xplained
# Pro evaluation kit, on a Unix-like system, with a GNU toolchain.

# We are on a Unix system so we assume a Single Unix compatible 'make'
# utility, and Unix defaults.
#include conf/Unix.mk

# Build directory.
BUILD = build

# Extension for executable files.
E =

# Extension for object files.
O = .o

# Prefix for library file name.
LP = lib

# Extension for library file name.
L = .a

# Prefix for DLL file name.
DP = lib

# Extension for DLL file name.
D = .so

# File deletion tool.
RM = rm -f

# Directory creation tool.
MKDIR = mkdir -p

# C compiler and flags.
#CC = cc
CFLAGS = -W -Wall -Os -ffunction-sections -fdata-sections
CCOUT = -c -o 

# Static linker.
#LD = cc
LDFLAGS = 
LDOUT = -o 

# We compile only the static library.
DLL = no
TOOLS = no
TESTS = no
