{sub( "^.*AA", "BB"); print}
