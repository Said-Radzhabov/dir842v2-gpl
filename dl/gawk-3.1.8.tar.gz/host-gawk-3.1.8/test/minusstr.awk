BEGIN { print-"6" }
