BEGIN {
	a += 2
}
