BEGIN { print asort(a) }
