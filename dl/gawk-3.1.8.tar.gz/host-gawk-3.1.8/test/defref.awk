BEGIN { foo() }
