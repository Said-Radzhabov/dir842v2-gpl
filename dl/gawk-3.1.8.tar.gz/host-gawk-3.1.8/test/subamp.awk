{ sub(/[a-z]/, "&") ; print }
