#include <stdio.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

#include "res_event.h"


int send_buf_to_daemon(char *buf, unsigned int cnt)
{
	//открываем в неблокирующем режиме, для проверки есть ли слушатель на том конце пайпа
	//иначе повиснем на open(), ENXIO - у пайпа нет слушателя
	int fd = open("/tmp/resident.events", O_WRONLY | O_NONBLOCK);

	if (fd < 0) {
		return errno;
	}

	//переключаемся в блокирующий режим
	int flags = fcntl(fd, F_GETFL, 0);
	flags &= ~O_NONBLOCK;
	fcntl(fd, F_SETFL, flags);

	//включаем игнорирование SIGPIPE, для того чтоб следующий write() закончился с EPIPE, если слушатель на pipe отвалился
	//иначе придет сигнал
	struct sigaction act, oldact;

	act.sa_handler = SIG_IGN;
	sigaction(SIGPIPE, &act, &oldact);
	
	int ret = write(fd, buf, cnt);
	int saved_errno = errno;

	//восстанавливаем предыдущий обработчик сигнала
	sigaction(SIGPIPE, &oldact, NULL);

	if (ret < 0)
		return saved_errno;

	close(fd);

	return 0;
}

extern char linkname[];

void _send_event_to_daemon(char *action, int unit, int code_status, pid_t pid, char *file, const char *func, unsigned int line)
{
	extern int a_auth;
	char bufecho[1024];
	char buffev [512];

	int cnt = 0;
	cnt += snprintf(buffev + cnt, sizeof(buffev) - cnt, "action:%s;", action);
	cnt += snprintf(buffev + cnt, sizeof(buffev) - cnt, "iface:ppp%d;", unit);
	cnt += snprintf(buffev + cnt, sizeof(buffev) - cnt, "status:%d;", code_status);
	cnt += snprintf(buffev + cnt, sizeof(buffev) - cnt, "link:%s;", linkname);
	if (a_auth)
		cnt += snprintf(buffev + cnt, sizeof(buffev) - cnt, "already:1;");

	cnt = snprintf(bufecho, sizeof(bufecho), "P%03u%s", cnt, buffev);

	notice("%s (from [%u]%s:%s[%d]) msg: [%s]", __func__, pid, file, func, line, bufecho);

	int ret = send_buf_to_daemon(bufecho, cnt);

	if (ret)
		notice("%s sending error, errno: %d (%s)", __func__, ret, strerror(ret));
}
