#ifndef __RES_EVENT_H__
#define __RES_EVENT_H__

#include <sys/types.h>
#include <unistd.h>

void _send_event_to_daemon(char *action, int unit, int code_status, pid_t pid, char *file, const char *func, unsigned int line);
#define send_event_to_daemon(action, unit, code_status)\
	_send_event_to_daemon(action, unit, code_status, getpid(), __FILE__, __func__, __LINE__)

#endif
