/***************************************************************************
 *   Copyright (C) 2013 by anikulin@dlink.ru aka farisey                   *
 *   anikulin@dlink.ru                                                     *
 *                                                                         *
 *   This program is _NOT_ free software!!!                                *
 *   It is commercial soft, property of D-Link Russia R&D.                 *
 ***************************************************************************/

#include "pppd.h"
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

#define DLOCK_PREFIX	"/tmp/dlock."

int dlock(const char *key);

static int dfd = -1;
static void dlock_cleanup();



static void dlock_cleanup()
{
	if (dfd == -1) {
		error("no dlock to cleanup!");
		return;
	}

	//не надо unlock flock. close закроет
	close(dfd);
	dfd = -1;//paranoid
}

int dlock(const char *key)
{
	struct flock flock;
	char name[256] = DLOCK_PREFIX, *x;
	int n = sizeof(DLOCK_PREFIX) - 1;
error("entering dlock, dfd = %d", dfd);
	if (dfd != -1) {
		error("!!! INTERNAL: dlock subseq call !!!");
		return 0;//-1;
	}

	snprintf(name + n, sizeof(name) - n, "%s", key);

	for (x = name + n; *x; x++)
		if (*x == '/')
			*x = '_';

	dfd = open(name, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);

	if (dfd == -1) {
		error("cannot open dlock: %s", strerror(errno));
		return -1;
	}

	memset(&flock, 0, sizeof(struct flock));
	flock.l_type = F_WRLCK;
	flock.l_whence = SEEK_SET;
	flock.l_start = 0;
	flock.l_len = 0;
	flock.l_pid = getpid();

	if (fcntl(dfd, F_SETLK, &flock) == 0) {
		info("dlock: locked");
		sprintf(name, "%u\n", (unsigned)getpid());
		ftruncate(dfd, 0);
		write(dfd, name, strlen(name));
		atexit(dlock_cleanup);
		return dfd;
	}

	//лочка не встала
	if ( (errno == EACCES) || (errno == EAGAIN) ) {
		error("already locked by another process");
		error("getting pid is unimplemented yet");
	} else
		error("dlock: flock: %s", strerror(errno));

	close(dfd);
	return (dfd = -1);
}
