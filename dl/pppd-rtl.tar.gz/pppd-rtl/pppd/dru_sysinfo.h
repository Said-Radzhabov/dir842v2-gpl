#ifndef __DRU_SYSINFO_H__
#define __DRU_SYSINFO_H__
#ifdef DRU_SYSINFO
#include <sys/sysinfo.h>
#include <sys/time.h>
static inline int dru_gettimeofday(struct timeval *tv, struct timezone *tz)
{
	struct sysinfo info;

	sysinfo(&info);
	tv->tv_sec = info.uptime;
	tv->tv_usec = 0;
	return 0;
}
#else
#define dru_gettimeofday gettimeofday
#endif
#endif
