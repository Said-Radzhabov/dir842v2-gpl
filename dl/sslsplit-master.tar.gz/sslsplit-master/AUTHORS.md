# Authors

SSLsplit was written and is being maintained by
[Daniel Roethlisberger](https://daniel.roe.ch/).

The following individuals have contributed to the codebase by submitting
patches or pull requests, in chronological order of their first contribution:

-   Steve Wills ([swills](https://github.com/swills))
-   Landon Fuller ([landonf](https://github.com/landonf))
-   Wayne Jensen ([wjjensen](https://github.com/wjjensen))
-   Rory McNamara ([psychomario](https://github.com/psychomario))
-   Alexander Neumann ([fd0](https://github.com/fd0))
-   Adam Jacob Muller ([AdamJacobMuller](https://github.com/AdamJacobMuller))
-   Richard Poole ([RichardPoole42](https://github.com/RichardPoole42))
-   Maciej Kotowicz ([mak](https://github.com/mak))
-   Eun Soo Park ([eunsoopark](https://github.com/eunsoopark))
-   Christian Groschupp ([cgroschupp](https://github.com/cgroschupp))
-   Alexander Savchenkov ([antalos](https://github.com/antalos))
-   Soner Tari ([sonertari](https://github.com/sonertari))
-   Petr Vaněk ([arkamar](https://github.com/arkamar))
-   Hilko Bengen ([hillu](https://github.com/hillu))
-   Philip Duldig ([pduldig-at-tw](https://github.com/pduldig-at-tw))

Many more individuals have contributed by reporting bugs or feature requests.
See [issue tracker on Github][1], `NEWS.md` and `git log` for details.

[1]: https://github.com/droe/sslsplit/issues

All your contributions are greatly appreciated; without you, SSLsplit would not
be what it is today.

